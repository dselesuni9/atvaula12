﻿namespace atividade12
{
    partial class cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtnome = new TextBox();
            btnsalvar = new Button();
            txtpreco = new TextBox();
            SuspendLayout();
            // 
            // txtnome
            // 
            txtnome.Location = new Point(347, 115);
            txtnome.Name = "txtnome";
            txtnome.Size = new Size(125, 27);
            txtnome.TabIndex = 0;
            txtnome.TextChanged += textBox1_TextChanged;
            // 
            // btnsalvar
            // 
            btnsalvar.Location = new Point(363, 327);
            btnsalvar.Name = "btnsalvar";
            btnsalvar.Size = new Size(94, 29);
            btnsalvar.TabIndex = 1;
            btnsalvar.Text = "Salvar";
            btnsalvar.UseVisualStyleBackColor = true;
            btnsalvar.Click += btnsalvar_Click;
            // 
            // txtpreco
            // 
            txtpreco.Location = new Point(349, 172);
            txtpreco.Name = "txtpreco";
            txtpreco.Size = new Size(125, 27);
            txtpreco.TabIndex = 2;
            txtpreco.TextChanged += textBox2_TextChanged;
            // 
            // cadastro
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtpreco);
            Controls.Add(btnsalvar);
            Controls.Add(txtnome);
            Name = "cadastro";
            Text = "cadastro";
            Load += cadastro_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtnome;
        private Button btnsalvar;
        private TextBox txtpreco;
    }
}